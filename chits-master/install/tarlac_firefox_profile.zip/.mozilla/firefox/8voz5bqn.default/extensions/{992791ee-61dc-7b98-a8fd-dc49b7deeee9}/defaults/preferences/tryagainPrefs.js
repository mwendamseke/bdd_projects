pref("extensions.tryagain.timeout", 60);
pref("extensions.tryagain.repeat", 10000);
pref("extensions.tryagain.showmenu", 0);
