pref("extensions.autohide.bars.statBar.always", false);
pref("extensions.autohide.bars.statBar", true);
pref("extensions.autohide.bars.nav-bar", true);
pref("extensions.autohide.bars.tabBar", true);
pref("extensions.autohide.delay", 50);
pref("extensions.autohide.hideDelay", 5);
pref("extensions.autohide.semiMode", false);
pref("extensions.autohide.senseArea", 0);
pref("extensions.autohide.toolTipUrl", false);
pref("extensions.autohide.windowsTB", true);
pref("extensions.autohide.zombieBorder", 2);


